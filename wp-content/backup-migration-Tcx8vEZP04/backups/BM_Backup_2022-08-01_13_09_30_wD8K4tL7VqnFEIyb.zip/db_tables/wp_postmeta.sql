/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_postmeta`; */
/* PRE_TABLE_NAME: `1659359370_wp_postmeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1659359370_wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1659359370_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
2,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
2,
3,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
3,
5,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
4,
5,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
5,
5,
'_menu_item_object_id',
5
/* VALUES END */
), (
/* VALUES START */
6,
5,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
7,
5,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
8,
5,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
9,
5,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
10,
5,
'_menu_item_url',
'http://localhost/complete/'
/* VALUES END */
), (
/* VALUES START */
11,
5,
'_menu_item_orphaned',
1658782547
/* VALUES END */
), (
/* VALUES START */
12,
6,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
13,
6,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
14,
6,
'_menu_item_object_id',
2
/* VALUES END */
), (
/* VALUES START */
15,
6,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
16,
6,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
17,
6,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
18,
6,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
19,
6,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
20,
6,
'_menu_item_orphaned',
1658782547
/* VALUES END */
), (
/* VALUES START */
21,
7,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
22,
7,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
23,
7,
'_menu_item_object_id',
7
/* VALUES END */
), (
/* VALUES START */
24,
7,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
25,
7,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
26,
7,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
27,
7,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
28,
7,
'_menu_item_url',
'http://localhost/complete/'
/* VALUES END */
), (
/* VALUES START */
29,
7,
'_menu_item_orphaned',
1658782659
/* VALUES END */
), (
/* VALUES START */
30,
8,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
31,
8,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
32,
8,
'_menu_item_object_id',
2
/* VALUES END */
), (
/* VALUES START */
33,
8,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
34,
8,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
35,
8,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
36,
8,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
37,
8,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
38,
8,
'_menu_item_orphaned',
1658782659
/* VALUES END */
), (
/* VALUES START */
39,
9,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
40,
9,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
41,
9,
'_menu_item_object_id',
9
/* VALUES END */
), (
/* VALUES START */
42,
9,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
43,
9,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
44,
9,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
45,
9,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
46,
9,
'_menu_item_url',
'http://localhost/complete/'
/* VALUES END */
), (
/* VALUES START */
48,
10,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
49,
10,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
50,
10,
'_menu_item_object_id',
2
/* VALUES END */
), (
/* VALUES START */
51,
10,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
52,
10,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
53,
10,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
54,
10,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
55,
10,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
57,
11,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
58,
11,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
59,
11,
'_menu_item_object_id',
11
/* VALUES END */
), (
/* VALUES START */
60,
11,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
61,
11,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
62,
11,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
63,
11,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
64,
11,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
65,
13,
'_um_custom_fields',
'a:6:{s:10:\"user_login\";a:15:{s:5:\"title\";s:8:\"Username\";s:7:\"metakey\";s:10:\"user_login\";s:4:\"type\";s:4:\"text\";s:5:\"label\";s:8:\"Username\";s:8:\"required\";i:1;s:6:\"public\";i:1;s:8:\"editable\";i:0;s:8:\"validate\";s:15:\"unique_username\";s:9:\"min_chars\";i:3;s:9:\"max_chars\";i:24;s:8:\"position\";s:1:\"1\";s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:8:\"in_group\";s:0:\"\";}s:10:\"user_email\";a:13:{s:5:\"title\";s:14:\"E-mail Address\";s:7:\"metakey\";s:10:\"user_email\";s:4:\"type\";s:4:\"text\";s:5:\"label\";s:14:\"E-mail Address\";s:8:\"required\";i:0;s:6:\"public\";i:1;s:8:\"editable\";i:1;s:8:\"validate\";s:12:\"unique_email\";s:8:\"position\";s:1:\"4\";s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:8:\"in_group\";s:0:\"\";}s:13:\"user_password\";a:16:{s:5:\"title\";s:8:\"Password\";s:7:\"metakey\";s:13:\"user_password\";s:4:\"type\";s:8:\"password\";s:5:\"label\";s:8:\"Password\";s:8:\"required\";i:1;s:6:\"public\";i:1;s:8:\"editable\";i:1;s:9:\"min_chars\";i:8;s:9:\"max_chars\";i:30;s:15:\"force_good_pass\";i:1;s:18:\"force_confirm_pass\";i:1;s:8:\"position\";s:1:\"5\";s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:8:\"in_group\";s:0:\"\";}s:10:\"first_name\";a:12:{s:5:\"title\";s:10:\"First Name\";s:7:\"metakey\";s:10:\"first_name\";s:4:\"type\";s:4:\"text\";s:5:\"label\";s:10:\"First Name\";s:8:\"required\";i:0;s:6:\"public\";i:1;s:8:\"editable\";i:1;s:8:\"position\";s:1:\"2\";s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:8:\"in_group\";s:0:\"\";}s:9:\"last_name\";a:12:{s:5:\"title\";s:9:\"Last Name\";s:7:\"metakey\";s:9:\"last_name\";s:4:\"type\";s:4:\"text\";s:5:\"label\";s:9:\"Last Name\";s:8:\"required\";i:0;s:6:\"public\";i:1;s:8:\"editable\";i:1;s:8:\"position\";s:1:\"3\";s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:8:\"in_group\";s:0:\"\";}s:9:\"_um_row_1\";a:4:{s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:8:\"sub_rows\";s:1:\"1\";s:4:\"cols\";s:1:\"1\";}}'
/* VALUES END */
), (
/* VALUES START */
66,
13,
'_um_mode',
'register'
/* VALUES END */
), (
/* VALUES START */
67,
13,
'_um_core',
'register'
/* VALUES END */
), (
/* VALUES START */
68,
13,
'_um_register_use_custom_settings',
0
/* VALUES END */
), (
/* VALUES START */
69,
14,
'_um_custom_fields',
'a:3:{s:8:\"username\";a:13:{s:5:\"title\";s:18:\"Username or E-mail\";s:7:\"metakey\";s:8:\"username\";s:4:\"type\";s:4:\"text\";s:5:\"label\";s:18:\"Username or E-mail\";s:8:\"required\";i:1;s:6:\"public\";i:1;s:8:\"editable\";i:0;s:8:\"validate\";s:24:\"unique_username_or_email\";s:8:\"position\";i:1;s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";i:1;s:8:\"in_group\";s:0:\"\";}s:13:\"user_password\";a:16:{s:5:\"title\";s:8:\"Password\";s:7:\"metakey\";s:13:\"user_password\";s:4:\"type\";s:8:\"password\";s:5:\"label\";s:8:\"Password\";s:8:\"required\";i:1;s:6:\"public\";i:1;s:8:\"editable\";i:1;s:9:\"min_chars\";i:8;s:9:\"max_chars\";i:30;s:15:\"force_good_pass\";i:1;s:18:\"force_confirm_pass\";i:1;s:8:\"position\";i:2;s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";i:1;s:8:\"in_group\";s:0:\"\";}s:9:\"_um_row_1\";a:5:{s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:8:\"sub_rows\";i:1;s:4:\"cols\";i:1;s:6:\"origin\";s:9:\"_um_row_1\";}}'
/* VALUES END */
), (
/* VALUES START */
70,
14,
'_um_mode',
'login'
/* VALUES END */
), (
/* VALUES START */
71,
14,
'_um_core',
'login'
/* VALUES END */
), (
/* VALUES START */
72,
14,
'_um_login_use_custom_settings',
1
/* VALUES END */
), (
/* VALUES START */
73,
15,
'_um_custom_fields',
'a:1:{s:9:\"_um_row_1\";a:4:{s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:8:\"sub_rows\";s:1:\"1\";s:4:\"cols\";s:1:\"1\";}}'
/* VALUES END */
), (
/* VALUES START */
74,
15,
'_um_mode',
'profile'
/* VALUES END */
), (
/* VALUES START */
75,
15,
'_um_core',
'profile'
/* VALUES END */
), (
/* VALUES START */
76,
15,
'_um_profile_use_custom_settings',
0
/* VALUES END */
), (
/* VALUES START */
77,
16,
'_um_core',
'members'
/* VALUES END */
), (
/* VALUES START */
78,
16,
'_um_template',
'members'
/* VALUES END */
), (
/* VALUES START */
79,
16,
'_um_mode',
'directory'
/* VALUES END */
), (
/* VALUES START */
80,
16,
'_um_view_types',
'a:1:{i:0;s:4:\"grid\";}'
/* VALUES END */
), (
/* VALUES START */
81,
16,
'_um_default_view',
'grid'
/* VALUES END */
), (
/* VALUES START */
82,
16,
'_um_roles',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
83,
16,
'_um_has_profile_photo',
0
/* VALUES END */
), (
/* VALUES START */
84,
16,
'_um_has_cover_photo',
0
/* VALUES END */
), (
/* VALUES START */
85,
16,
'_um_show_these_users',
''
/* VALUES END */
), (
/* VALUES START */
86,
16,
'_um_exclude_these_users',
''
/* VALUES END */
), (
/* VALUES START */
87,
16,
'_um_sortby',
'user_registered_desc'
/* VALUES END */
), (
/* VALUES START */
88,
16,
'_um_sortby_custom',
''
/* VALUES END */
), (
/* VALUES START */
89,
16,
'_um_sortby_custom_label',
''
/* VALUES END */
), (
/* VALUES START */
90,
16,
'_um_enable_sorting',
0
/* VALUES END */
), (
/* VALUES START */
91,
16,
'_um_sorting_fields',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
92,
16,
'_um_profile_photo',
1
/* VALUES END */
), (
/* VALUES START */
93,
16,
'_um_cover_photos',
1
/* VALUES END */
), (
/* VALUES START */
94,
16,
'_um_show_name',
1
/* VALUES END */
), (
/* VALUES START */
95,
16,
'_um_show_tagline',
0
/* VALUES END */
), (
/* VALUES START */
96,
16,
'_um_tagline_fields',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
97,
16,
'_um_show_userinfo',
0
/* VALUES END */
), (
/* VALUES START */
98,
16,
'_um_reveal_fields',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
99,
16,
'_um_show_social',
0
/* VALUES END */
), (
/* VALUES START */
100,
16,
'_um_userinfo_animate',
1
/* VALUES END */
), (
/* VALUES START */
101,
16,
'_um_search',
0
/* VALUES END */
), (
/* VALUES START */
102,
16,
'_um_roles_can_search',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
103,
16,
'_um_filters',
0
/* VALUES END */
), (
/* VALUES START */
104,
16,
'_um_roles_can_filter',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
105,
16,
'_um_search_fields',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
106,
16,
'_um_filters_expanded',
0
/* VALUES END */
), (
/* VALUES START */
107,
16,
'_um_filters_is_collapsible',
1
/* VALUES END */
), (
/* VALUES START */
108,
16,
'_um_search_filters',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
109,
16,
'_um_must_search',
0
/* VALUES END */
), (
/* VALUES START */
110,
16,
'_um_max_users',
''
/* VALUES END */
), (
/* VALUES START */
111,
16,
'_um_profiles_per_page',
12
/* VALUES END */
), (
/* VALUES START */
112,
16,
'_um_profiles_per_page_mobile',
6
/* VALUES END */
), (
/* VALUES START */
113,
16,
'_um_directory_header',
'{total_users} Members'
/* VALUES END */
), (
/* VALUES START */
114,
16,
'_um_directory_header_single',
'{total_users} Member'
/* VALUES END */
), (
/* VALUES START */
115,
16,
'_um_directory_no_users',
'We are sorry. We cannot find any users who match your search criteria.'
/* VALUES END */
), (
/* VALUES START */
123,
1,
'_um_core',
'pages_settings'
/* VALUES END */
), (
/* VALUES START */
131,
17,
'_um_core',
'user'
/* VALUES END */
), (
/* VALUES START */
132,
18,
'_um_core',
'login'
/* VALUES END */
), (
/* VALUES START */
133,
19,
'_um_core',
'register'
/* VALUES END */
), (
/* VALUES START */
134,
20,
'_um_core',
'members'
/* VALUES END */
), (
/* VALUES START */
135,
21,
'_um_core',
'logout'
/* VALUES END */
), (
/* VALUES START */
136,
22,
'_um_core',
'account'
/* VALUES END */
), (
/* VALUES START */
137,
23,
'_um_core',
'password-reset'
/* VALUES END */
), (
/* VALUES START */
138,
18,
'_edit_lock',
'1659357096:1'
/* VALUES END */
), (
/* VALUES START */
139,
14,
'_edit_lock',
'1659357311:1'
/* VALUES END */
), (
/* VALUES START */
140,
14,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
141,
14,
'_um_register_use_custom_settings',
''
/* VALUES END */
), (
/* VALUES START */
142,
14,
'_um_register_role',
0
/* VALUES END */
), (
/* VALUES START */
143,
14,
'_um_register_template',
'register'
/* VALUES END */
), (
/* VALUES START */
144,
14,
'_um_register_max_width',
'450px'
/* VALUES END */
), (
/* VALUES START */
145,
14,
'_um_register_icons',
'label'
/* VALUES END */
), (
/* VALUES START */
146,
14,
'_um_register_primary_btn_word',
'Register'
/* VALUES END */
), (
/* VALUES START */
147,
14,
'_um_register_secondary_btn',
''
/* VALUES END */
), (
/* VALUES START */
148,
14,
'_um_register_secondary_btn_word',
'Login'
/* VALUES END */
), (
/* VALUES START */
149,
14,
'_um_register_use_gdpr',
''
/* VALUES END */
), (
/* VALUES START */
150,
14,
'_um_register_use_gdpr_content_id',
0
/* VALUES END */
), (
/* VALUES START */
151,
14,
'_um_register_use_gdpr_toggle_show',
'Show privacy policy'
/* VALUES END */
), (
/* VALUES START */
152,
14,
'_um_register_use_gdpr_toggle_hide',
'Hide privacy policy'
/* VALUES END */
), (
/* VALUES START */
153,
14,
'_um_register_use_gdpr_agreement',
'Please confirm that you agree to our privacy policy'
/* VALUES END */
), (
/* VALUES START */
154,
14,
'_um_register_use_gdpr_error_text',
'Please confirm your acceptance of our privacy policy'
/* VALUES END */
), (
/* VALUES START */
155,
14,
'_um_profile_use_custom_settings',
''
/* VALUES END */
), (
/* VALUES START */
156,
14,
'_um_profile_role',
''
/* VALUES END */
), (
/* VALUES START */
157,
14,
'_um_profile_template',
'profile'
/* VALUES END */
), (
/* VALUES START */
158,
14,
'_um_profile_max_width',
'1000px'
/* VALUES END */
), (
/* VALUES START */
159,
14,
'_um_profile_area_max_width',
'600px'
/* VALUES END */
), (
/* VALUES START */
160,
14,
'_um_profile_icons',
'label'
/* VALUES END */
), (
/* VALUES START */
161,
14,
'_um_profile_primary_btn_word',
'Update Profile'
/* VALUES END */
), (
/* VALUES START */
162,
14,
'_um_profile_secondary_btn',
''
/* VALUES END */
), (
/* VALUES START */
163,
14,
'_um_profile_secondary_btn_word',
'Cancel'
/* VALUES END */
), (
/* VALUES START */
164,
14,
'_um_profile_cover_enabled',
''
/* VALUES END */
), (
/* VALUES START */
165,
14,
'_um_profile_coversize',
300
/* VALUES END */
), (
/* VALUES START */
166,
14,
'_um_profile_cover_ratio',
'2.7:1'
/* VALUES END */
), (
/* VALUES START */
167,
14,
'_um_profile_disable_photo_upload',
''
/* VALUES END */
), (
/* VALUES START */
168,
14,
'_um_profile_photosize',
190
/* VALUES END */
), (
/* VALUES START */
169,
14,
'_um_profile_photo_required',
''
/* VALUES END */
), (
/* VALUES START */
170,
14,
'_um_profile_show_name',
''
/* VALUES END */
), (
/* VALUES START */
171,
14,
'_um_profile_show_social_links',
''
/* VALUES END */
), (
/* VALUES START */
172,
14,
'_um_profile_show_bio',
''
/* VALUES END */
), (
/* VALUES START */
173,
14,
'_um_login_template',
'login'
/* VALUES END */
), (
/* VALUES START */
174,
14,
'_um_login_max_width',
'450px'
/* VALUES END */
), (
/* VALUES START */
175,
14,
'_um_login_icons',
'label'
/* VALUES END */
), (
/* VALUES START */
176,
14,
'_um_login_primary_btn_word',
'Login'
/* VALUES END */
), (
/* VALUES START */
177,
14,
'_um_login_secondary_btn',
1
/* VALUES END */
), (
/* VALUES START */
178,
14,
'_um_login_secondary_btn_word',
'Register'
/* VALUES END */
), (
/* VALUES START */
179,
14,
'_um_login_forgot_pass_link',
1
/* VALUES END */
), (
/* VALUES START */
180,
14,
'_um_login_show_rememberme',
1
/* VALUES END */
), (
/* VALUES START */
181,
14,
'_um_login_after_login',
0
/* VALUES END */
), (
/* VALUES START */
182,
14,
'_um_login_redirect_url',
''
/* VALUES END */
), (
/* VALUES START */
183,
22,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
184,
22,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
185,
22,
'_wp_desired_post_slug',
'account'
/* VALUES END */
), (
/* VALUES START */
186,
18,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
187,
18,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
188,
18,
'_wp_desired_post_slug',
'login'
/* VALUES END */
), (
/* VALUES START */
189,
21,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
190,
21,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
191,
21,
'_wp_desired_post_slug',
'logout'
/* VALUES END */
), (
/* VALUES START */
192,
20,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
193,
20,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
194,
20,
'_wp_desired_post_slug',
'members'
/* VALUES END */
), (
/* VALUES START */
195,
23,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
196,
23,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
197,
23,
'_wp_desired_post_slug',
'password-reset'
/* VALUES END */
), (
/* VALUES START */
198,
3,
'_wp_trash_meta_status',
'draft'
/* VALUES END */
), (
/* VALUES START */
199,
3,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
200,
3,
'_wp_desired_post_slug',
'privacy-policy'
/* VALUES END */
), (
/* VALUES START */
201,
19,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
202,
19,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
203,
19,
'_wp_desired_post_slug',
'register'
/* VALUES END */
), (
/* VALUES START */
204,
2,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
205,
2,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
206,
2,
'_wp_desired_post_slug',
'sample-page'
/* VALUES END */
), (
/* VALUES START */
207,
17,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
208,
17,
'_wp_trash_meta_time',
1659357474
/* VALUES END */
), (
/* VALUES START */
209,
17,
'_wp_desired_post_slug',
'user'
/* VALUES END */
), (
/* VALUES START */
210,
13,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
211,
13,
'_wp_trash_meta_time',
1659357488
/* VALUES END */
), (
/* VALUES START */
212,
13,
'_wp_desired_post_slug',
'default-registration'
/* VALUES END */
), (
/* VALUES START */
213,
14,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
214,
14,
'_wp_trash_meta_time',
1659357488
/* VALUES END */
), (
/* VALUES START */
215,
14,
'_wp_desired_post_slug',
'default-login'
/* VALUES END */
), (
/* VALUES START */
216,
15,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
217,
15,
'_wp_trash_meta_time',
1659357488
/* VALUES END */
), (
/* VALUES START */
218,
15,
'_wp_desired_post_slug',
'default-profile'
/* VALUES END */
), (
/* VALUES START */
219,
34,
'_um_custom_fields',
'a:3:{s:8:\"username\";a:17:{s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";i:1;s:8:\"in_group\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:7:\"metakey\";s:8:\"username\";s:8:\"position\";i:1;s:5:\"title\";s:18:\"Username or E-mail\";s:9:\"min_chars\";i:0;s:10:\"visibility\";s:3:\"all\";s:5:\"label\";s:18:\"Username or E-mail\";s:6:\"public\";s:1:\"1\";s:8:\"validate\";s:24:\"unique_username_or_email\";s:9:\"max_chars\";i:0;s:8:\"required\";b:1;s:8:\"editable\";b:0;s:4:\"icon\";s:22:\"um-icon-android-person\";}s:13:\"user_password\";a:17:{s:5:\"title\";s:8:\"Password\";s:7:\"metakey\";s:13:\"user_password\";s:4:\"type\";s:8:\"password\";s:5:\"label\";s:8:\"Password\";s:8:\"required\";i:1;s:6:\"public\";i:1;s:8:\"editable\";i:1;s:9:\"min_chars\";i:8;s:9:\"max_chars\";i:30;s:15:\"force_good_pass\";i:1;s:18:\"force_confirm_pass\";i:1;s:18:\"label_confirm_pass\";s:16:\"Confirm Password\";s:8:\"position\";i:2;s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";i:1;s:8:\"in_group\";s:0:\"\";}s:9:\"_um_row_1\";a:14:{s:8:\"sub_rows\";i:1;s:4:\"cols\";i:1;s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:10:\"background\";s:7:\"#ffffff\";s:10:\"text_color\";s:7:\"#000000\";s:7:\"padding\";s:15:\"0px 0px 0px 0px\";s:6:\"margin\";s:16:\"0px 0px 30px 0px\";s:6:\"border\";s:15:\"0px 0px 0px 0px\";s:12:\"borderradius\";s:3:\"0px\";s:11:\"borderstyle\";s:5:\"solid\";s:7:\"heading\";b:1;s:4:\"icon\";s:29:\"um-icon-android-notifications\";s:6:\"origin\";s:9:\"_um_row_1\";}}'
/* VALUES END */
), (
/* VALUES START */
220,
34,
'_edit_lock',
'1659358523:1'
/* VALUES END */
), (
/* VALUES START */
221,
34,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
222,
34,
'_um_register_use_custom_settings',
''
/* VALUES END */
), (
/* VALUES START */
223,
34,
'_um_register_role',
0
/* VALUES END */
), (
/* VALUES START */
224,
34,
'_um_register_template',
'register'
/* VALUES END */
), (
/* VALUES START */
225,
34,
'_um_register_max_width',
'450px'
/* VALUES END */
), (
/* VALUES START */
226,
34,
'_um_register_icons',
'label'
/* VALUES END */
), (
/* VALUES START */
227,
34,
'_um_register_primary_btn_word',
'Register'
/* VALUES END */
), (
/* VALUES START */
228,
34,
'_um_register_secondary_btn',
1
/* VALUES END */
), (
/* VALUES START */
229,
34,
'_um_register_secondary_btn_word',
'Login'
/* VALUES END */
), (
/* VALUES START */
230,
34,
'_um_register_use_gdpr',
''
/* VALUES END */
), (
/* VALUES START */
231,
34,
'_um_register_use_gdpr_content_id',
0
/* VALUES END */
), (
/* VALUES START */
232,
34,
'_um_register_use_gdpr_toggle_show',
'Show privacy policy'
/* VALUES END */
), (
/* VALUES START */
233,
34,
'_um_register_use_gdpr_toggle_hide',
'Hide privacy policy'
/* VALUES END */
), (
/* VALUES START */
234,
34,
'_um_register_use_gdpr_agreement',
'Please confirm that you agree to our privacy policy'
/* VALUES END */
), (
/* VALUES START */
235,
34,
'_um_register_use_gdpr_error_text',
'Please confirm your acceptance of our privacy policy'
/* VALUES END */
), (
/* VALUES START */
236,
34,
'_um_profile_use_custom_settings',
''
/* VALUES END */
), (
/* VALUES START */
237,
34,
'_um_profile_role',
''
/* VALUES END */
), (
/* VALUES START */
238,
34,
'_um_profile_template',
'profile'
/* VALUES END */
), (
/* VALUES START */
239,
34,
'_um_profile_max_width',
'1000px'
/* VALUES END */
), (
/* VALUES START */
240,
34,
'_um_profile_area_max_width',
'600px'
/* VALUES END */
), (
/* VALUES START */
241,
34,
'_um_profile_icons',
'label'
/* VALUES END */
), (
/* VALUES START */
242,
34,
'_um_profile_primary_btn_word',
'Update Profile'
/* VALUES END */
), (
/* VALUES START */
243,
34,
'_um_profile_secondary_btn',
1
/* VALUES END */
), (
/* VALUES START */
244,
34,
'_um_profile_secondary_btn_word',
'Cancel'
/* VALUES END */
), (
/* VALUES START */
245,
34,
'_um_profile_cover_enabled',
1
/* VALUES END */
), (
/* VALUES START */
246,
34,
'_um_profile_coversize',
300
/* VALUES END */
), (
/* VALUES START */
247,
34,
'_um_profile_cover_ratio',
'2.7:1'
/* VALUES END */
), (
/* VALUES START */
248,
34,
'_um_profile_disable_photo_upload',
''
/* VALUES END */
), (
/* VALUES START */
249,
34,
'_um_profile_photosize',
190
/* VALUES END */
), (
/* VALUES START */
250,
34,
'_um_profile_photo_required',
''
/* VALUES END */
), (
/* VALUES START */
251,
34,
'_um_profile_show_name',
1
/* VALUES END */
), (
/* VALUES START */
252,
34,
'_um_profile_show_social_links',
''
/* VALUES END */
), (
/* VALUES START */
253,
34,
'_um_profile_show_bio',
1
/* VALUES END */
), (
/* VALUES START */
254,
34,
'_um_login_use_custom_settings',
1
/* VALUES END */
), (
/* VALUES START */
255,
34,
'_um_login_template',
'login'
/* VALUES END */
), (
/* VALUES START */
256,
34,
'_um_login_max_width',
'450px'
/* VALUES END */
), (
/* VALUES START */
257,
34,
'_um_login_icons',
'field'
/* VALUES END */
), (
/* VALUES START */
258,
34,
'_um_login_primary_btn_word',
'Login'
/* VALUES END */
), (
/* VALUES START */
259,
34,
'_um_login_secondary_btn',
''
/* VALUES END */
), (
/* VALUES START */
260,
34,
'_um_login_secondary_btn_word',
'Register'
/* VALUES END */
), (
/* VALUES START */
261,
34,
'_um_login_forgot_pass_link',
''
/* VALUES END */
), (
/* VALUES START */
262,
34,
'_um_login_show_rememberme',
''
/* VALUES END */
), (
/* VALUES START */
263,
34,
'_um_login_after_login',
'redirect_url'
/* VALUES END */
), (
/* VALUES START */
264,
34,
'_um_login_redirect_url',
'http://localhost/complete/home/'
/* VALUES END */
), (
/* VALUES START */
265,
34,
'_um_mode',
'login'
/* VALUES END */
), (
/* VALUES START */
266,
35,
'_edit_lock',
'1659357622:1'
/* VALUES END */
), (
/* VALUES START */
267,
35,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
268,
35,
'um_content_restriction',
'a:8:{s:26:\"_um_custom_access_settings\";b:0;s:14:\"_um_accessible\";i:0;s:28:\"_um_access_hide_from_queries\";b:0;s:19:\"_um_noaccess_action\";i:0;s:30:\"_um_restrict_by_custom_message\";i:0;s:27:\"_um_restrict_custom_message\";s:0:\"\";s:19:\"_um_access_redirect\";i:0;s:23:\"_um_access_redirect_url\";s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
269,
39,
'_edit_lock',
'1659358576:1'
/* VALUES END */
), (
/* VALUES START */
270,
39,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
271,
39,
'um_content_restriction',
'a:8:{s:26:\"_um_custom_access_settings\";b:0;s:14:\"_um_accessible\";i:0;s:28:\"_um_access_hide_from_queries\";b:0;s:19:\"_um_noaccess_action\";i:0;s:30:\"_um_restrict_by_custom_message\";i:0;s:27:\"_um_restrict_custom_message\";s:0:\"\";s:19:\"_um_access_redirect\";i:0;s:23:\"_um_access_redirect_url\";s:0:\"\";}'
/* VALUES END */
);
/* QUERY END */

