/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1658863363_wp_term_relationships`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1658863363_wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1658863363_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES ( 
/* VALUES START */
1,
1,
0
/* VALUES END */
), (
/* VALUES START */
9,
2,
0
/* VALUES END */
), (
/* VALUES START */
10,
2,
0
/* VALUES END */
), (
/* VALUES START */
11,
2,
0
/* VALUES END */
);
/* QUERY END */

