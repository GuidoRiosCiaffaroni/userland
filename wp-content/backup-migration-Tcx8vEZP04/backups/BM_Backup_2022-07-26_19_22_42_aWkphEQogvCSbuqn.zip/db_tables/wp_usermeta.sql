/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_usermeta`; */
/* PRE_TABLE_NAME: `1658863363_wp_usermeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1658863363_wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1658863363_wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
1,
'nickname',
'admin'
/* VALUES END */
), (
/* VALUES START */
2,
1,
'first_name',
''
/* VALUES END */
), (
/* VALUES START */
3,
1,
'last_name',
''
/* VALUES END */
), (
/* VALUES START */
4,
1,
'description',
''
/* VALUES END */
), (
/* VALUES START */
5,
1,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
6,
1,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
7,
1,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
8,
1,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
9,
1,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
10,
1,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
11,
1,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
12,
1,
'wp_capabilities',
'a:1:{s:13:\"administrator\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
13,
1,
'wp_user_level',
10
/* VALUES END */
), (
/* VALUES START */
14,
1,
'dismissed_wp_pointers',
''
/* VALUES END */
), (
/* VALUES START */
15,
1,
'show_welcome_panel',
0
/* VALUES END */
), (
/* VALUES START */
17,
1,
'wp_dashboard_quick_press_last_post_id',
4
/* VALUES END */
), (
/* VALUES START */
18,
1,
'blankslate_notice_dismissed_7',
'true'
/* VALUES END */
), (
/* VALUES START */
21,
1,
'managenav-menuscolumnshidden',
'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'
/* VALUES END */
), (
/* VALUES START */
22,
1,
'metaboxhidden_nav-menus',
'a:1:{i:0;s:12:\"add-post_tag\";}'
/* VALUES END */
), (
/* VALUES START */
24,
1,
'session_tokens',
'a:1:{s:64:\"2cddbd35f61aed594f8e08b94411ac8a3eac681e4b13a9127374e4a9ed26ea19\";a:4:{s:10:\"expiration\";i:1659031220;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36\";s:5:\"login\";i:1658858420;}}'
/* VALUES END */
), (
/* VALUES START */
25,
1,
'nav_menu_recently_edited',
2
/* VALUES END */
);
/* QUERY END */

