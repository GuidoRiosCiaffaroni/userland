/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_postmeta`; */
/* PRE_TABLE_NAME: `1658863363_wp_postmeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1658863363_wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1658863363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
2,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
2,
3,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
3,
5,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
4,
5,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
5,
5,
'_menu_item_object_id',
5
/* VALUES END */
), (
/* VALUES START */
6,
5,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
7,
5,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
8,
5,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
9,
5,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
10,
5,
'_menu_item_url',
'http://localhost/complete/'
/* VALUES END */
), (
/* VALUES START */
11,
5,
'_menu_item_orphaned',
1658782547
/* VALUES END */
), (
/* VALUES START */
12,
6,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
13,
6,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
14,
6,
'_menu_item_object_id',
2
/* VALUES END */
), (
/* VALUES START */
15,
6,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
16,
6,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
17,
6,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
18,
6,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
19,
6,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
20,
6,
'_menu_item_orphaned',
1658782547
/* VALUES END */
), (
/* VALUES START */
21,
7,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
22,
7,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
23,
7,
'_menu_item_object_id',
7
/* VALUES END */
), (
/* VALUES START */
24,
7,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
25,
7,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
26,
7,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
27,
7,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
28,
7,
'_menu_item_url',
'http://localhost/complete/'
/* VALUES END */
), (
/* VALUES START */
29,
7,
'_menu_item_orphaned',
1658782659
/* VALUES END */
), (
/* VALUES START */
30,
8,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
31,
8,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
32,
8,
'_menu_item_object_id',
2
/* VALUES END */
), (
/* VALUES START */
33,
8,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
34,
8,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
35,
8,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
36,
8,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
37,
8,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
38,
8,
'_menu_item_orphaned',
1658782659
/* VALUES END */
), (
/* VALUES START */
39,
9,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
40,
9,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
41,
9,
'_menu_item_object_id',
9
/* VALUES END */
), (
/* VALUES START */
42,
9,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
43,
9,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
44,
9,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
45,
9,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
46,
9,
'_menu_item_url',
'http://localhost/complete/'
/* VALUES END */
), (
/* VALUES START */
48,
10,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
49,
10,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
50,
10,
'_menu_item_object_id',
2
/* VALUES END */
), (
/* VALUES START */
51,
10,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
52,
10,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
53,
10,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
54,
10,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
55,
10,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
57,
11,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
58,
11,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
59,
11,
'_menu_item_object_id',
11
/* VALUES END */
), (
/* VALUES START */
60,
11,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
61,
11,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
62,
11,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
63,
11,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
64,
11,
'_menu_item_url',
'#'
/* VALUES END */
);
/* QUERY END */

